#!/usr/bin/env python3
"""
Скрипт для автоматического создания структуры базы данных PostgreSQL.
"""

import os
import sys
import argparse
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

def get_db_config(args):
    """Получение конфигурации БД из аргументов или переменных окружения"""
    config = {
        'host': args.host or os.getenv('DB_HOST', 'localhost'),
        'port': args.port or os.getenv('DB_PORT', '5432'),
        'user': args.user or os.getenv('DB_USER', 'postgres'),
        'password': args.password or os.getenv('DB_PASSWORD', ''),
        'database': args.database or os.getenv('DB_NAME', 'scholarship_portal')
    }
    
    if not config['password'] and not args.no_password:
        import getpass
        config['password'] = getpass.getpass(f"Введите пароль для пользователя {config['user']}: ")
    
    return config

def create_database(db_config, drop_existing=False):
    """Создание базы данных"""
    try:
        print(f"\nПодключение к PostgreSQL серверу {db_config['host']}:{db_config['port']}...")
        
        # Подключаемся к серверу PostgreSQL
        conn = psycopg2.connect(
            host=db_config['host'],
            port=db_config['port'],
            user=db_config['user'],
            password=db_config['password']
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        db_name = db_config['database']
        
        # Проверяем существование базы данных
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
        exists = cursor.fetchone()
        
        if exists:
            if drop_existing:
                print(f"База данных '{db_name}' уже существует. Удаляем...")
                cursor.execute(f"DROP DATABASE {db_name}")
                print(f"База данных '{db_name}' удалена.")
            else:
                print(f"База данных '{db_name}' уже существует. Пропускаем создание.")
                cursor.close()
                conn.close()
                return True
        
        # Создаем базу данных
        print(f"Создаем базу данных '{db_name}'...")
        cursor.execute(f"""
            CREATE DATABASE {db_name} 
            ENCODING 'UTF8' 
            LC_COLLATE 'ru_RU.UTF-8' 
            LC_CTYPE 'ru_RU.UTF-8' 
            TEMPLATE template0
        """)
        
        cursor.close()
        conn.close()
        
        print(f"✓ База данных '{db_name}' успешно создана!")
        return True
        
    except psycopg2.OperationalError as e:
        print(f"✗ Ошибка подключения к PostgreSQL: {e}")
        print("\nУбедитесь, что:")
        print("1. PostgreSQL установлен и запущен")
        print("2. Указаны правильные параметры подключения")
        print("3. Пользователь имеет права на создание баз данных")
        return False
    except Exception as e:
        print(f"✗ Ошибка при создании базы данных: {e}")
        return False

def test_connection(db_config):
    """Тестирование подключения к созданной базе данных"""
    try:
        conn = psycopg2.connect(
            host=db_config['host'],
            port=db_config['port'],
            user=db_config['user'],
            password=db_config['password'],
            database=db_config['database']
        )
        cursor = conn.cursor()
        
        # Простой запрос для проверки
        cursor.execute("SELECT version()")
        version = cursor.fetchone()[0]
        
        cursor.close()
        conn.close()
        
        print(f"✓ Подключение успешно. PostgreSQL версия: {version}")
        return True
        
    except Exception as e:
        print(f"✗ Ошибка подключения к базе данных: {e}")
        return False

def print_success_message(db_config):
    """Вывод сообщения об успешном создании"""
    print("\n" + "="*60)
    print("БАЗА ДАННЫХ УСПЕШНО СОЗДАНА!")
    print("="*60)
    print("\nПараметры подключения:")
    print(f"  Хост:     {db_config['host']}")
    print(f"  Порт:     {db_config['port']}")
    print(f"  База:     {db_config['database']}")
    print(f"  Пользователь: {db_config['user']}")
    
    print("\nДля Flask приложения используйте строку подключения:")
    connection_string = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"
    print(f"  {connection_string}")
    
    print("\nТеперь запустите приложение для создания таблиц:")
    print("  python app.py")
    print("="*60)

def main():
    parser = argparse.ArgumentParser(description='Создание базы данных PostgreSQL для Scholarship Portal')
    
    parser.add_argument('--host', help='Хост PostgreSQL (по умолчанию: localhost)')
    parser.add_argument('--port', help='Порт PostgreSQL (по умолчанию: 5432)')
    parser.add_argument('--user', help='Пользователь PostgreSQL (по умолчанию: postgres)')
    parser.add_argument('--password', help='Пароль пользователя PostgreSQL')
    parser.add_argument('--database', help='Имя базы данных (по умолчанию: scholarship_portal)')
    parser.add_argument('--drop-existing', action='store_true', help='Удалить существующую базу данных')
    parser.add_argument('--no-password', action='store_true', help='Не запрашивать пароль (использовать пустой)')
    
    args = parser.parse_args()
    
    print("="*60)
    print("СОЗДАНИЕ БАЗЫ ДАННЫХ ДЛЯ SCHOLARSHIP PORTAL")
    print("="*60)
    
    # Получаем конфигурацию
    db_config = get_db_config(args)
    
    # Создаем базу данных
    if not create_database(db_config, args.drop_existing):
        return 1
    
    # Тестируем подключение
    if not test_connection(db_config):
        return 1
    
    # Выводим информацию
    print_success_message(db_config)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())