from database import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    full_name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), default='student')
    class_name = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    created_diplomas = db.relationship('Diploma', backref='creator', lazy=True)
    participations = db.relationship('Participation', foreign_keys='Participation.student_id', backref='student_rel', lazy=True)
    mentored = db.relationship('Participation', foreign_keys='Participation.mentor_id', backref='mentor_rel', lazy=True)
    rating = db.relationship('Rating', backref='student_rating', lazy=True, uselist=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        return self.role == 'admin'
    
    def is_teacher(self):
        return self.role == 'teacher'
    
    # Свойство для получения дипломов
    @property
    def diplomas(self):
        return [p.diploma for p in self.participations]

class Diploma(db.Model):
    __tablename__ = 'diplomas'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    level = db.Column(db.String(50), nullable=False)
    participation_type = db.Column(db.String(50), default='оффлайн')
    points = db.Column(db.Integer, nullable=False)
    file_path = db.Column(db.String(500))
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    
    # Relationships
    participations = db.relationship('Participation', backref='diploma_rel', lazy=True, cascade='all, delete-orphan')

class Participation(db.Model):
    __tablename__ = 'participations'
    
    id = db.Column(db.Integer, primary_key=True)
    diploma_id = db.Column(db.Integer, db.ForeignKey('diplomas.id', ondelete='CASCADE'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    mentor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Добавляем уникальное ограничение на уровне таблицы
    __table_args__ = (
        db.UniqueConstraint('diploma_id', 'student_id', name='unique_diploma_student'),
    )
    
    # Свойства для удобного доступа
    @property
    def diploma(self):
        return db.session.get(Diploma, self.diploma_id)
    
    @property
    def student(self):
        return db.session.get(User, self.student_id)
    
    @property
    def mentor(self):
        return db.session.get(User, self.mentor_id) if self.mentor_id else None

class Rating(db.Model):
    __tablename__ = 'ratings'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    total_points = db.Column(db.Integer, default=0)
    academic_points = db.Column(db.Integer, default=0)
    extracurricular_points = db.Column(db.Integer, default=0)
    position = db.Column(db.Integer)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

class News(db.Model):
    __tablename__ = 'news'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50))
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_published = db.Column(db.Boolean, default=True)
    
    author = db.relationship('User', backref='news_items')

class AuditLog(db.Model):
    __tablename__ = 'audit_log'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    action = db.Column(db.String(200), nullable=False)
    table_name = db.Column(db.String(50))
    record_id = db.Column(db.Integer)
    old_data = db.Column(db.JSON)
    new_data = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='audit_logs')