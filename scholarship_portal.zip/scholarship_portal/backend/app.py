from flask import Flask, render_template
from config import Config
from database import db, login_manager
from models import User, Diploma, Participation, Rating, News, AuditLog
from routes import main
import os
from sqlalchemy import text
from datetime import datetime

# Получаем пути
project_root = os.path.dirname(os.path.abspath(__file__))
frontend_path = os.path.join(os.path.dirname(project_root), 'frontend')

print("=" * 60)
print("НАСТРОЙКИ СЕРВЕРА:")
print(f"Проект: {os.path.dirname(project_root)}")
print(f"Frontend папка: {frontend_path}")
print("=" * 60)

def create_app():
    app = Flask(__name__, 
                template_folder=frontend_path,
                static_folder=frontend_path)
    app.config.from_object(Config)
    
    # Инициализация расширений
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'
    
    # Регистрация blueprint
    app.register_blueprint(main)
    
    # Создание папки для загрузок
    upload_folder = os.path.join(project_root, app.config['UPLOAD_FOLDER'])
    os.makedirs(upload_folder, exist_ok=True)
    
    return app

def fix_sequences():
    """Исправление последовательностей в PostgreSQL"""
    with app.app_context():
        tables = ['users', 'diplomas', 'participations', 'ratings', 'news', 'audit_log']
        
        for table in tables:
            try:
                # Сбрасываем последовательность для каждой таблицы
                db.session.execute(text(f"""
                    SELECT setval(pg_get_serial_sequence('{table}', 'id'), 
                    COALESCE((SELECT MAX(id) FROM {table}), 1), false);
                """))
                db.session.commit()
                print(f"✓ Последовательность для {table} исправлена")
            except Exception as e:
                print(f"✗ Ошибка при исправлении последовательности {table}: {e}")
                db.session.rollback()

def create_test_users():
    """Создание тестовых пользователей"""
    try:
        # Проверяем, есть ли уже пользователи
        if User.query.first():
            print("✓ Пользователи уже существуют")
            return
        
        print("Создание тестовых пользователей...")
        
        # Администратор
        admin = User(
            username='admin',
            email='admin@school.edu',
            full_name='Администратор Системы',
            role='admin'
        )
        admin.set_password('admin123')
        db.session.add(admin)
        
        # Учитель
        teacher = User(
            username='teacher1',
            email='teacher1@school.edu',
            full_name='Петрова Мария Ивановна',
            role='teacher'
        )
        teacher.set_password('teacher123')
        db.session.add(teacher)
        
        db.session.flush()  # Получаем ID учителя
        
        # Ученики
        students_data = [
            ('Иванов Иван', '10А', 'student1', 'student123'),
            ('Петрова Анна', '11Б', 'student2', 'student123'),
            ('Сидоров Максим', '10Б', 'student3', 'student123'),
            ('Козлова Елена', '11А', 'student4', 'student123'),
            ('Смирнов Алексей', '10А', 'student5', 'student123')
        ]
        
        students = []
        for full_name, class_name, username, password in students_data:
            student = User(
                username=username,
                email=f'{username}@school.edu',
                full_name=full_name,
                role='student',
                class_name=class_name
            )
            student.set_password(password)
            db.session.add(student)
            students.append(student)
        
        db.session.commit()
        print("✓ Тестовые пользователи созданы")
        
        # Создаем записи в рейтинге для учеников
        print("Создание записей рейтинга...")
        for student in students:
            rating = Rating(student_id=student.id, total_points=0)
            db.session.add(rating)
        
        db.session.commit()
        print("✓ Записи рейтинга созданы")
        
        # Создаем тестовые дипломы
        create_test_diplomas(teacher.id, students[:2])  # Первые 2 ученика
        create_test_news(admin.id)
        
    except Exception as e:
        db.session.rollback()
        print(f"✗ Ошибка при создании тестовых пользователей: {e}")

def create_test_diplomas(teacher_id, students):
    """Создание тестовых дипломов"""
    try:
        if Diploma.query.first():
            print("✓ Дипломы уже существуют")
            return
        
        print("Создание тестовых дипломов...")
        
        test_diplomas = [
            ('Победитель олимпиады по математике', 'городской', 20),
            ('Призер конкурса проектов', 'региональный', 30),
            ('Участник научной конференции', 'федеральный', 40),
            ('Спортивные достижения', 'районный', 10),
            ('Конкурс чтецов', 'городской', 20),
        ]
        
        for title, level, points in test_diplomas:
            diploma = Diploma(
                title=title,
                level=level,
                points=points,
                created_by=teacher_id,
                participation_type='оффлайн',
                created_at=datetime.utcnow()
            )
            db.session.add(diploma)
            db.session.flush()  # Получаем ID диплома
            
            # Назначаем учеников
            for student in students:
                participation = Participation(
                    diploma_id=diploma.id,
                    student_id=student.id,
                    mentor_id=teacher_id
                )
                db.session.add(participation)
        
        db.session.commit()
        print("✓ Тестовые дипломы созданы")
        
        # Обновляем рейтинги вручную (простой подсчет)
        for student in students:
            total_points = sum(d.points for d in student.participations)
            rating = Rating.query.filter_by(student_id=student.id).first()
            if rating:
                rating.total_points = total_points
        
        db.session.commit()
        print("✓ Рейтинги обновлены")
        
    except Exception as e:
        db.session.rollback()
        print(f"✗ Ошибка при создании тестовых дипломов: {e}")

def create_test_news(admin_id):
    """Создание тестовых новостей"""
    try:
        if News.query.first():
            print("✓ Новости уже существуют")
            return
        
        print("Создание тестовых новостей...")
        
        test_news = [
            ('Новый учебный год', 'Начинается новый учебный год 2024-2025', 'Образование'),
            ('Олимпиада по программированию', 'Приглашаем принять участие в олимпиаде', 'Наука'),
            ('Спортивные соревнования', 'Школьные соревнования по баскетболу', 'Спорт'),
        ]
        
        for title, content, category in test_news:
            news = News(
                title=title,
                content=content,
                category=category,
                author_id=admin_id,
                is_published=True
            )
            db.session.add(news)
        
        db.session.commit()
        print("✓ Тестовые новости созданы")
        
    except Exception as e:
        db.session.rollback()
        print(f"✗ Ошибка при создании тестовых новостей: {e}")

def init_database():
    """Инициализация базы данных"""
    with app.app_context():
        try:
            # Создаем таблицы если их нет
            db.create_all()
            print("✓ Таблицы созданы")
            
            # Исправляем последовательности
            fix_sequences()
            
            # Создаем тестовые данные
            create_test_users()
            
        except Exception as e:
            print(f"✗ Ошибка при инициализации базы данных: {e}")

if __name__ == '__main__':
    app = create_app()
    
    # Инициализация базы данных
    init_database()
    
    print(f"\nСервер запущен: http://localhost:5000")
    print(f"   Для входа используйте:")
    print(f"   Админ: admin / admin123")
    print(f"   Учитель: teacher1 / teacher123")
    print(f"   Ученики: student1..student5 / student123")
    print(f"\nОсновные страницы:")
    print(f"   Главная: /")
    print(f"   Личный кабинет: /dashboard")
    print(f"   Мои дипломы: /my_diplomas")
    print(f"   Рейтинг: /rating")
    print(f"   Доска почета: /honor_board")
    
    app.run(debug=False, host='0.0.0.0', port=5000)