from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash, send_from_directory, send_file
from flask_login import login_user, logout_user, login_required, current_user
from database import db
from models import User, Diploma, Participation, Rating, News, AuditLog
from datetime import datetime, timedelta
from sqlalchemy import func
import os
import json
from werkzeug.utils import secure_filename
import io
import csv

main = Blueprint('main', __name__)

# Получаем путь к frontend
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')

# ========== МАРШРУТЫ ДЛЯ СТАТИЧЕСКИХ ФАЙЛОВ ==========
@main.route('/css/<path:filename>')
def serve_css(filename):
    return send_from_directory(os.path.join(FRONTEND_DIR, 'css'), filename)

@main.route('/js/<path:filename>')
def serve_js(filename):
    return send_from_directory(os.path.join(FRONTEND_DIR, 'js'), filename)

@main.route('/favicon.ico')
def favicon():
    return send_from_directory(FRONTEND_DIR, 'favicon.ico')

# ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========
def log_audit(action, table_name=None, record_id=None, old_data=None, new_data=None):
    """Логирование действий пользователей"""
    if current_user.is_authenticated:
        log = AuditLog(
            user_id=current_user.id,
            action=action,
            table_name=table_name,
            record_id=record_id,
            old_data=old_data,
            new_data=new_data
        )
        db.session.add(log)
        db.session.commit()

def allowed_file(filename):
    """Проверка допустимых расширений файлов"""
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def calculate_points(level):
    """Расчет баллов на основе уровня достижения"""
    points_map = {
        'районный': 10,
        'городской': 20,
        'региональный': 30,
        'федеральный': 40,
        'международный': 50
    }
    return points_map.get(level, 0)

# ========== ОСНОВНЫЕ МАРШРУТЫ ==========
@main.route('/')
def index():
    """Главная страница"""
    return render_template('index.html')

@main.route('/test')
def test():
    """Тестовая страница для проверки"""
    return """
    <!DOCTYPE html>
    <html>
    <head><title>Тест</title></head>
    <body style="padding: 40px; font-family: Arial;">
        <h1>Сервер работает!</h1>
        <p>Тестовые страницы:</p>
        <ul>
            <li><a href="/">Главная</a></li>
            <li><a href="/login">Вход</a></li>
            <li><a href="/register_page">Регистрация</a></li>
            <li><a href="/dashboard">Личный кабинет</a> (требует входа)</li>
        </ul>
    </body>
    </html>
    """

@main.route('/login', methods=['GET', 'POST'])
def login():
    """Страница входа"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            log_audit(f'Вход в систему пользователем {username}')
            return redirect(url_for('main.dashboard'))
        
        flash('Неверное имя пользователя или пароль')
    
    return render_template('login.html')

@main.route('/logout')
@login_required
def logout():
    """Выход из системы"""
    log_audit(f'Выход из системы пользователем {current_user.username}')
    logout_user()
    return redirect(url_for('main.index'))

# ========== ЛИЧНЫЙ КАБИНЕТ И ПРОФИЛЬ ==========
@main.route('/dashboard')
@login_required
def dashboard():
    """Личный кабинет"""
    # Получаем рейтинг пользователя
    rating = Rating.query.filter_by(student_id=current_user.id).first()
    
    # Получаем последние грамоты (максимум 5)
    participations = Participation.query.filter_by(student_id=current_user.id)\
        .order_by(Participation.created_at.desc()).limit(5).all()
    diplomas = [p.diploma for p in participations] if participations else []
    
    # Получаем новости
    news = News.query.filter_by(is_published=True)\
        .order_by(News.created_at.desc()).limit(5).all()
    
    # Собираем статистику
    total_diplomas = Participation.query.filter_by(student_id=current_user.id).count()
    
    # Считаем количество дипломов по уровням
    level_stats = {}
    total_points = 0
    
    for diploma in diplomas:
        total_points += diploma.points
        level = diploma.level
        level_stats[level] = level_stats.get(level, 0) + 1
    
    return render_template('dashboard.html', 
                         user=current_user,
                         rating=rating,
                         diplomas=diplomas,
                         news=news,
                         total_diplomas=total_diplomas,
                         total_points=total_points,
                         level_stats=level_stats)

@main.route('/profile')
@login_required
def profile():
    """Страница профиля"""
    rating = Rating.query.filter_by(student_id=current_user.id).first()
    
    # Получаем статистику достижений
    participations = Participation.query.filter_by(student_id=current_user.id).all()
    diplomas = [p.diploma for p in participations] if participations else []
    
    # Считаем статистику по уровням
    level_stats = {}
    total_points = 0
    highest_level = None
    
    for diploma in diplomas:
        total_points += diploma.points
        level = diploma.level
        level_stats[level] = level_stats.get(level, 0) + 1
        
        # Определяем высший уровень
        level_order = ['районный', 'городской', 'региональный', 'федеральный', 'международный']
        if highest_level is None or level_order.index(level) > level_order.index(highest_level):
            highest_level = level
    
    profile_data = {
        'user': current_user,
        'rating': rating,
        'total_diplomas': len(diplomas),
        'total_points': total_points,
        'average_points': round(total_points / len(diplomas), 1) if diplomas else 0,
        'highest_level': highest_level,
        'level_stats': level_stats
    }
    
    return render_template('profile.html', **profile_data)

@main.route('/my_diplomas')
@login_required
def my_diplomas():
    """Страница моих дипломов"""
    # Получаем все дипломы пользователя
    participations = Participation.query.filter_by(student_id=current_user.id)\
        .order_by(Participation.created_at.desc()).all()
    diplomas = [p.diploma for p in participations] if participations else []
    
    # Собираем статистику
    total_points = sum(d.points for d in diplomas)
    
    return render_template('my_diplomas.html', 
                         diplomas=diplomas,
                         total_points=total_points,
                         total_diplomas=len(diplomas))

@main.route('/add_diploma', methods=['GET', 'POST'])
@login_required
def add_diploma():
    """Добавление новой грамоты"""
    from sqlalchemy.exc import IntegrityError
    
    # Для GET запроса
    if request.method == 'GET':
        students = User.query.filter_by(role='student').all()
        teachers = User.query.filter_by(role='teacher').all()
        return render_template('add_diploma.html', 
                             students=students, 
                             teachers=teachers)
    
    # Для POST запроса
    students = User.query.filter_by(role='student').all()
    teachers = User.query.filter_by(role='teacher').all()
    
    try:
        print("\n" + "="*60)
        print("НАЧАЛО ОБРАБОТКИ ФОРМЫ")
        print("="*60)
        
        # Получаем данные
        title = request.form.get('title', '').strip()
        if not title:
            flash('Пожалуйста, укажите название грамоты', 'error')
            return render_template('add_diploma.html', 
                                 students=students, 
                                 teachers=teachers)
        
        level = request.form.get('level', '').strip()
        if not level:
            flash('Пожалуйста, выберите уровень достижения', 'error')
            return render_template('add_diploma.html', 
                                 students=students, 
                                 teachers=teachers)
        
        # Получаем учеников
        student_ids = []
        for sid in request.form.getlist('students[]'):
            if sid and sid.strip():
                try:
                    student_ids.append(int(sid))
                except ValueError:
                    pass
        
        if not student_ids:
            flash('Пожалуйста, выберите хотя бы одного ученика', 'error')
            return render_template('add_diploma.html', 
                                 students=students, 
                                 teachers=teachers)
        
        # Получаем наставников
        mentor_ids = []
        for mid in request.form.getlist('mentors[]'):
            if mid and mid.strip():
                try:
                    mentor_ids.append(int(mid))
                except ValueError:
                    pass
        
        # Определяем баллы
        points_str = request.form.get('points', '')
        if points_str:
            try:
                points = int(points_str)
            except ValueError:
                points = calculate_points(level)
        else:
            points = calculate_points(level)
        
        print(f"Данные: '{title}', уровень: {level}, баллы: {points}")
        print(f"Ученики: {student_ids}")
        
        # === СОЗДАЕМ ДИПЛОМ ===
        diploma = Diploma(
            title=title,
            description=request.form.get('description', '').strip(),
            level=level,
            participation_type=request.form.get('participation_type', 'оффлайн'),
            points=points,
            created_by=current_user.id,
            created_at=datetime.utcnow()
        )
        
        # Обрабатываем даты
        for date_field in ['start_date', 'end_date']:
            date_str = request.form.get(date_field)
            if date_str:
                try:
                    setattr(diploma, date_field, datetime.strptime(date_str, '%Y-%m-%d'))
                except:
                    pass
        
        # Обрабатываем файл
        if 'document' in request.files:
            file = request.files['document']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join('uploads', f"{int(datetime.now().timestamp())}_{filename}")
                upload_path = os.path.join(BASE_DIR, '..', filepath)
                os.makedirs(os.path.dirname(upload_path), exist_ok=True)
                file.save(upload_path)
                diploma.file_path = filepath
        
        db.session.add(diploma)
        db.session.flush()  # Получаем ID
        
        print(f"✓ Создан диплом ID: {diploma.id}")
        
        # === СОЗДАЕМ УЧАСТИЯ ===
        mentor_id = None
        if mentor_ids:
            mentor_id = mentor_ids[0]
        elif current_user.role in ['teacher', 'admin']:
            mentor_id = current_user.id
        
        participations_created = 0
        error_messages = []
        
        for student_id in student_ids:
            try:
                # Пытаемся создать запись
                participation = Participation(
                    diploma_id=diploma.id,
                    student_id=student_id,
                    mentor_id=mentor_id,
                    created_at=datetime.utcnow()
                )
                
                db.session.add(participation)
                participations_created += 1
                print(f"✓ Создано участие для ученика {student_id}")
                
            except IntegrityError as ie:
                # Если возникла ошибка уникальности (дубликат)
                db.session.rollback()
                error_messages.append(f"Ученик ID {student_id} уже участвует в этой грамоте")
                print(f"✗ Ошибка уникальности для ученика {student_id}")
                # Продолжаем с остальными учениками
                continue
            except Exception as e:
                error_messages.append(f"Ошибка для ученика {student_id}: {str(e)}")
                print(f"✗ Ошибка для ученика {student_id}: {e}")
                continue
        
        if participations_created == 0:
            # Если ни одна запись не создана
            db.session.rollback()
            flash('Не удалось создать ни одного участия. Возможно, все выбранные ученики уже участвуют в этой грамоте.', 'error')
            return render_template('add_diploma.html', 
                                 students=students, 
                                 teachers=teachers)
        
        # === СОХРАНЯЕМ ИЗМЕНЕНИЯ ===
        try:
            db.session.commit()
            print(f"✓ Успешно сохранено. Создано {participations_created} участий")
            
            # Обновляем рейтинги
            for student_id in student_ids:
                try:
                    update_student_rating(student_id)
                except Exception as e:
                    print(f"Ошибка обновления рейтинга для {student_id}: {e}")
            
            update_all_ratings_positions()
            
            # Логируем
            log_audit('Добавлена грамота', 'diplomas', diploma.id, None, {'title': title})
            
            if error_messages:
                flash(f'Грамота добавлена для {participations_created} учеников, но были ошибки: {", ".join(error_messages[:3])}', 'warning')
            else:
                flash(f'Грамота успешно добавлена для {participations_created} учеников!', 'success')
            
            return redirect(url_for('main.my_diplomas'))
            
        except Exception as e:
            db.session.rollback()
            print(f"✗ Ошибка при сохранении: {e}")
            flash(f'Ошибка при сохранении грамоты: {str(e)}', 'error')
            return render_template('add_diploma.html', 
                                 students=students, 
                                 teachers=teachers)
    
    except Exception as e:
        print(f"✗ Критическая ошибка: {e}")
        flash(f'Критическая ошибка: {str(e)}', 'error')
        return render_template('add_diploma.html', 
                             students=students, 
                             teachers=teachers)
    
def create_participation_safe(diploma_id, student_id, mentor_id=None):
    """Безопасное создание записи об участии с проверкой дубликатов"""
    try:
        # Проверяем существование
        existing = Participation.query.filter_by(
            diploma_id=diploma_id,
            student_id=student_id
        ).first()
        
        if existing:
            print(f"Запись уже существует: diploma_id={diploma_id}, student_id={student_id}")
            return existing
        
        # Создаем новую запись
        participation = Participation(
            diploma_id=diploma_id,
            student_id=student_id,
            mentor_id=mentor_id,
            created_at=datetime.utcnow()
        )
        
        db.session.add(participation)
        return participation
        
    except Exception as e:
        print(f"Ошибка при создании участия: {e}")
        raise
    
@main.route('/clean_participation_duplicates')
@login_required
def clean_participation_duplicates():
    """Очистка всех дубликатов в participations"""
    if current_user.role != 'admin':
        return "Доступ запрещен", 403
    
    from sqlalchemy import text
    
    try:
        # SQL для удаления дубликатов (оставляет самую старую запись)
        sql = """
        WITH duplicates AS (
            SELECT id,
                   ROW_NUMBER() OVER (
                       PARTITION BY diploma_id, student_id 
                       ORDER BY created_at
                   ) as row_num
            FROM participations
        )
        DELETE FROM participations 
        WHERE id IN (
            SELECT id FROM duplicates WHERE row_num > 1
        )
        """
        
        result = db.session.execute(text(sql))
        db.session.commit()
        
        return f"Удалено {result.rowcount} дубликатов"
    except Exception as e:
        db.session.rollback()
        return f"Ошибка: {str(e)}", 500
    
@main.route('/force_update_all_ratings')
@login_required
def force_update_all_ratings():
    """Принудительное обновление всех рейтингов"""
    if current_user.role != 'admin':
        return "Доступ запрещен", 403
    
    students = User.query.filter_by(role='student').all()
    results = []
    
    for student in students:
        try:
            rating = update_student_rating(student.id)
            if rating:
                results.append({
                    'student_id': student.id,
                    'name': student.full_name,
                    'points': rating.total_points,
                    'status': 'success'
                })
            else:
                results.append({
                    'student_id': student.id,
                    'name': student.full_name,
                    'status': 'failed'
                })
        except Exception as e:
            results.append({
                'student_id': student.id,
                'name': student.full_name,
                'status': 'error',
                'error': str(e)
            })
    
    # Обновляем позиции
    update_all_ratings_positions()
    
    return jsonify({
        'total_students': len(students),
        'results': results
    })
    
def update_student_rating(student_id):
    """Обновление рейтинга для конкретного ученика"""
    try:
        print(f"Обновление рейтинга для student_id={student_id}")
        
        # Считаем сумму баллов всех дипломов ученика
        total_points = db.session.query(func.sum(Diploma.points))\
            .join(Participation, Participation.diploma_id == Diploma.id)\
            .filter(Participation.student_id == student_id)\
            .scalar() or 0
        
        print(f"Найдено баллов: {total_points}")
        
        # Находим или создаем запись рейтинга
        rating = Rating.query.filter_by(student_id=student_id).first()
        if rating:
            print(f"Обновляем существующий рейтинг ID: {rating.id}")
            rating.total_points = total_points
            rating.updated_at = datetime.utcnow()
        else:
            print(f"Создаем новый рейтинг для student_id={student_id}")
            rating = Rating(student_id=student_id, total_points=total_points)
            db.session.add(rating)
        
        db.session.commit()
        print(f"✓ Рейтинг обновлен для student_id={student_id}: {total_points} баллов")
        return rating
    except Exception as e:
        print(f"✗ Ошибка при обновлении рейтинга для student_id={student_id}: {e}")
        import traceback
        traceback.print_exc()
        db.session.rollback()
        return None
    
def update_all_ratings_positions():
    """Обновление позиций всех учеников в рейтинге"""
    try:
        # Получаем все рейтинги, отсортированные по убыванию баллов
        all_ratings = Rating.query\
            .join(User, Rating.student_id == User.id)\
            .filter(User.role == 'student')\
            .order_by(Rating.total_points.desc())\
            .all()
        
        # Обновляем позиции
        for i, rating in enumerate(all_ratings):
            rating.position = i + 1
        
        db.session.commit()
        print(f"✓ Обновлены позиции для {len(all_ratings)} учеников")
    except Exception as e:
        print(f"✗ Ошибка при обновлении позиций: {e}")
        db.session.rollback()

# ========== РЕЙТИНГ И ДОСКА ПОЧЕТА ==========
@main.route('/rating')
@login_required
def rating():
    """Страница рейтинга"""
    print("\n" + "="*60)
    print("ОБРАБОТКА МАРШРУТА /rating")
    print("="*60)
    
    # 1. Получаем всех студентов
    students = User.query.filter_by(role='student').all()
    print(f"Найдено студентов в базе: {len(students)}")
    
    if not students:
        print("Внимание: нет студентов в базе данных!")
        return render_template('rating.html', 
                             ratings=[], 
                             total_participants=0,
                             average_points=0,
                             max_points=0,
                             min_points=0)
    
    # 2. Убеждаемся, что у всех студентов есть запись в Rating
    for student in students:
        rating = Rating.query.filter_by(student_id=student.id).first()
        if not rating:
            print(f"Создаем рейтинг для студента: {student.full_name} (ID: {student.id})")
            rating = Rating(student_id=student.id, total_points=0)
            db.session.add(rating)
    
    db.session.commit()
    
    # 3. Обновляем рейтинг для всех студентов
    for student in students:
        update_student_rating(student.id)
    
    # 4. Обновляем позиции
    update_all_ratings_positions()
    
    # 5. Получаем отсортированный рейтинг
    ratings = Rating.query\
        .join(User, Rating.student_id == User.id)\
        .filter(User.role == 'student')\
        .order_by(Rating.total_points.desc())\
        .all()
    
    print(f"Записей в рейтинге после обновления: {len(ratings)}")
    
    # 6. Формируем данные для шаблона
    result = []
    for i, rating in enumerate(ratings):
        student = User.query.get(rating.student_id)
        if student:
            # Получаем достижения студента
            participations = Participation.query.filter_by(student_id=student.id).all()
            diplomas = [p.diploma for p in participations] if participations else []
            
            # Разделяем баллы
            academic_points = 0
            extracurricular_points = 0
            
            for diploma in diplomas:
                if diploma and diploma.points:
                    if diploma.level in ['районный', 'городской']:
                        academic_points += diploma.points
                    else:
                        extracurricular_points += diploma.points
            
            result.append({
                'id': student.id,
                'position': i + 1,
                'full_name': student.full_name or student.username,
                'class': student.class_name or 'Не указан',
                'total_points': rating.total_points or 0,
                'academic_points': academic_points,
                'extracurricular_points': extracurricular_points
            })
            
            print(f"  {i+1}. {student.full_name}: {rating.total_points} баллов")
    
    # 7. Считаем статистику
    total_participants = len(result)
    total_points = sum(r['total_points'] for r in result)
    average_points = round(total_points / total_participants) if total_participants > 0 else 0
    max_points = max((r['total_points'] for r in result), default=0)
    min_points = min((r['total_points'] for r in result), default=0)
    
    print(f"\nСТАТИСТИКА:")
    print(f"  Участников: {total_participants}")
    print(f"  Всего баллов: {total_points}")
    print(f"  Средний балл: {average_points}")
    print("="*60)
    
    return render_template('rating.html',
                         ratings=result,
                         total_participants=total_participants,
                         average_points=average_points,
                         max_points=max_points,
                         min_points=min_points)
@main.route('/honor_board')
@login_required
def honor_board():
    """Доска почета"""
    # Получаем лучших учеников за текущий месяц
    current_month = datetime.utcnow().month
    current_year = datetime.utcnow().year
    
    # Получаем учеников с наибольшим количеством баллов
    top_students = []
    
    # Для демонстрации берем топ-8 учеников
    ratings = Rating.query.order_by(Rating.total_points.desc()).limit(8).all()
    
    for rating in ratings:
        student = User.query.get(rating.student_id)
        if student and student.role == 'student':
            # Получаем достижения ученика
            participations = Participation.query.filter_by(student_id=student.id)\
                .order_by(Participation.created_at.desc()).limit(3).all()
            
            achievements = []
            for p in participations:
                diploma = Diploma.query.get(p.diploma_id)
                if diploma:
                    achievements.append({
                        'title': diploma.title,
                        'level': diploma.level
                    })
            
            top_students.append({
                'id': student.id,
                'name': student.full_name,
                'class': student.class_name,
                'points': rating.total_points,
                'achievements': achievements,
                'avatar': ''.join([n[0] for n in student.full_name.split()[:2]])
            })
    
    return render_template('honor_board.html', 
                         top_students=top_students,
                         current_month=current_month,
                         current_year=current_year)

# ========== НОВОСТИ ==========
@main.route('/news')
@login_required
def news():
    """Страница новостей"""
    news_list = News.query.filter_by(is_published=True)\
        .order_by(News.created_at.desc()).all()
    
    return render_template('news.html', news=news_list)

@main.route('/api/news', methods=['POST'])
@login_required
def add_news():
    """Добавление новости (только для админов и учителей)"""
    if current_user.role not in ['admin', 'teacher']:
        return jsonify({'error': 'Недостаточно прав'}), 403
    
    data = request.json
    
    news_item = News(
        title=data.get('title'),
        content=data.get('content'),
        category=data.get('category', 'Объявления'),
        author_id=current_user.id,
        is_published=True
    )
    
    db.session.add(news_item)
    db.session.commit()
    
    log_audit('Добавлена новость', 'news', news_item.id, None, {'title': data.get('title')})
    
    return jsonify({'message': 'Новость успешно добавлена', 'id': news_item.id}), 201

# ========== РЕГИСТРАЦИЯ ==========
@main.route('/register_page')
def register_page():
    """Страница регистрации (HTML форма)"""
    return render_template('register.html')

@main.route('/register', methods=['POST'])
def register_api():
    """Обработка регистрации (API)"""
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    role = data.get('role', 'student')
    
    # Проверяем, существует ли пользователь
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Пользователь с таким именем уже существует'}), 400
    
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Пользователь с таким email уже существует'}), 400
    
    # Создаем нового пользователя
    user = User(
        username=username,
        email=email,
        full_name=full_name,
        role=role
    )
    user.set_password(password)
    
    db.session.add(user)
    db.session.commit()
    
    # Создаем запись в рейтинге (только для учеников)
    if role == 'student':
        rating = Rating(student_id=user.id)
        db.session.add(rating)
        db.session.commit()
    
    log_audit('Регистрация нового пользователя', 'users', user.id, None, {'username': username})
    
    return jsonify({'message': 'Пользователь успешно зарегистрирован'}), 201

@main.route('/add_unique_constraint')
@login_required
def add_unique_constraint():
    """Добавление ограничения уникальности к таблице participations"""
    if current_user.role != 'admin':
        return "Доступ запрещен", 403
    
    from sqlalchemy import text
    
    try:
        # 1. Сначала удаляем дубликаты
        delete_sql = text("""
            DELETE FROM participations 
            WHERE id IN (
                SELECT p1.id
                FROM participations p1
                JOIN participations p2 ON p1.diploma_id = p2.diploma_id 
                    AND p1.student_id = p2.student_id 
                    AND p1.id > p2.id
            )
        """)
        
        delete_result = db.session.execute(delete_sql)
        duplicates_deleted = delete_result.rowcount
        
        # 2. Добавляем ограничение уникальности
        try:
            constraint_sql = text("""
                ALTER TABLE participations 
                ADD CONSTRAINT unique_diploma_student 
                UNIQUE (diploma_id, student_id)
            """)
            db.session.execute(constraint_sql)
            constraint_added = True
        except Exception as e:
            constraint_added = False
            constraint_error = str(e)
        
        # 3. Сбрасываем sequence
        try:
            reset_sql = text("SELECT setval('participations_id_seq', (SELECT MAX(id) FROM participations) + 1, false)")
            db.session.execute(reset_sql)
            sequence_reset = True
        except:
            sequence_reset = False
        
        db.session.commit()
        
        result = {
            'duplicates_deleted': duplicates_deleted,
            'constraint_added': constraint_added,
            'sequence_reset': sequence_reset,
            'message': 'Попытка исправления завершена'
        }
        
        if not constraint_added:
            result['constraint_error'] = constraint_error
        
        return jsonify(result)
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@main.route('/debug_tables')
def debug_tables():
    """Отладочная информация о таблицах"""
    result = {}
    
    # Проверяем структуру таблицы participations
    from sqlalchemy import inspect
    inspector = inspect(db.engine)
    
    # Получаем информацию о таблице
    columns = inspector.get_columns('participations')
    indexes = inspector.get_indexes('participations')
    constraints = inspector.get_unique_constraints('participations')
    
    result['participations'] = {
        'columns': [{'name': c['name'], 'type': str(c['type'])} for c in columns],
        'indexes': indexes,
        'constraints': constraints
    }
    
    # Считаем записи
    from models import Participation
    participations = Participation.query.all()
    result['count'] = len(participations)
    
    # Первые 5 записей
    result['sample'] = [
        {'id': p.id, 'diploma_id': p.diploma_id, 'student_id': p.student_id, 'mentor_id': p.mentor_id}
        for p in participations[:5]
    ]
    
    return jsonify(result)

# ========== API МАРШРУТЫ ==========
@main.route('/api/diplomas', methods=['GET'])
@login_required
def get_diplomas():
    """Получение всех дипломов пользователя"""
    participations = Participation.query.filter_by(student_id=current_user.id).all()
    diplomas = [p.diploma for p in participations] if participations else []
    
    result = []
    for d in diplomas:
        result.append({
            'id': d.id,
            'title': d.title,
            'description': d.description,
            'level': d.level,
            'participation_type': d.participation_type,
            'points': d.points,
            'created_at': d.created_at.strftime('%Y-%m-%d') if d.created_at else None,
            'start_date': d.start_date.strftime('%Y-%m-%d') if d.start_date else None,
            'end_date': d.end_date.strftime('%Y-%m-%d') if d.end_date else None
        })
    
    return jsonify(result)

@main.route('/api/diplomas/<int:diploma_id>', methods=['DELETE'])
@login_required
def delete_diploma(diploma_id):
    """Удаление диплома"""
    diploma = Diploma.query.get_or_404(diploma_id)
    
    # Проверяем права (только создатель или админ может удалять)
    if diploma.created_by != current_user.id and current_user.role != 'admin':
        return jsonify({'error': 'Недостаточно прав'}), 403
    
    # Удаляем связанные записи об участии
    Participation.query.filter_by(diploma_id=diploma_id).delete()
    
    # Удаляем сам диплом
    db.session.delete(diploma)
    db.session.commit()
    
    log_audit('Удалена грамота', 'diplomas', diploma_id, {'title': diploma.title}, None)
    
    return jsonify({'message': 'Диплом успешно удален'}), 200

@main.route('/api/users/<role>', methods=['GET'])
@login_required
def get_users_by_role(role):
    """Получение пользователей по роли"""
    users = User.query.filter_by(role=role).all()
    result = []
    for u in users:
        result.append({
            'id': u.id,
            'full_name': u.full_name,
            'class': u.class_name,
            'email': u.email,
            'username': u.username
        })
    return jsonify(result)

@main.route('/api/rating/top10', methods=['GET'])
def get_top10_rating():
    """Топ-10 рейтинга"""
    ratings = Rating.query.order_by(Rating.total_points.desc()).limit(10).all()
    result = []
    for r in ratings:
        student = User.query.get(r.student_id)
        if student:
            result.append({
                'position': r.position,
                'name': f"{student.full_name.split()[0]} {student.full_name.split()[1][0]}.",
                'class': student.class_name,
                'points': r.total_points
            })
    return jsonify(result)

@main.route('/api/rating/data', methods=['GET'])
@login_required
def get_rating_data():
    """API для получения данных рейтинга в JSON формате"""
    print("\n[API /api/rating/data] Получение данных рейтинга")
    
    # Используем ту же логику, что и в маршруте /rating
    update_all_ratings_positions()
    
    # Получаем рейтинг всех учеников
    ratings = Rating.query\
        .join(User, Rating.student_id == User.id)\
        .filter(User.role == 'student')\
        .order_by(Rating.total_points.desc())\
        .all()
    
    print(f"  Найдено записей в рейтинге: {len(ratings)}")
    
    result = []
    for i, rating in enumerate(ratings):
        student = User.query.get(rating.student_id)
        if student:
            print(f"  Обработка студента: {student.full_name} (ID: {student.id})")
            
            # Получаем достижения студента
            participations = Participation.query.filter_by(student_id=student.id).all()
            diplomas = [p.diploma for p in participations] if participations else []
            
            print(f"    Дипломов: {len(diplomas)}")
            
            # Разделяем баллы
            academic_points = 0
            extracurricular_points = 0
            
            for diploma in diplomas:
                if diploma and diploma.points:
                    if diploma.level in ['районный', 'городской']:
                        academic_points += diploma.points
                    else:
                        extracurricular_points += diploma.points
            
            result.append({
                'id': student.id,
                'position': i + 1,
                'full_name': student.full_name or student.username,
                'class': student.class_name or 'Не указан',
                'total_points': rating.total_points or 0,
                'academic_points': academic_points,
                'extracurricular_points': extracurricular_points
            })
    
    print(f"  Отправлено записей: {len(result)}")
    return jsonify(result)

@main.route('/api/rating/export', methods=['GET'])
@login_required
def export_rating():
    """Экспорт рейтинга в CSV"""
    ratings = Rating.query.order_by(Rating.total_points.desc()).all()
    
    # Создаем CSV в памяти
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Заголовки
    writer.writerow(['Место', 'ФИО', 'Класс', 'Общие баллы', 'Учебные баллы', 'Внеучебные баллы'])
    
    # Данные
    for i, rating in enumerate(ratings):
        student = User.query.get(rating.student_id)
        if student and student.role == 'student':
            writer.writerow([
                i + 1,
                student.full_name,
                student.class_name,
                rating.total_points,
                rating.academic_points,
                rating.extracurricular_points
            ])
    
    # Возвращаем файл
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='рейтинг.csv'
    )

@main.route('/api/profile/update', methods=['POST'])
@login_required
def update_profile():
    """Обновление профиля пользователя"""
    data = request.json
    
    # Обновляем данные пользователя
    if 'full_name' in data:
        current_user.full_name = data['full_name']
    
    if 'email' in data and data['email'] != current_user.email:
        # Проверяем, не занят ли email
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email уже используется'}), 400
        current_user.email = data['email']
    
    if 'phone' in data:
        current_user.phone = data['phone']
    
    if 'class_name' in data:
        current_user.class_name = data['class_name']
    
    db.session.commit()
    
    log_audit('Обновлен профиль пользователя', 'users', current_user.id, None, data)
    
    return jsonify({'message': 'Профиль успешно обновлен'}), 200

@main.route('/api/profile/change_password', methods=['POST'])
@login_required
def change_password():
    """Смена пароля"""
    data = request.json
    current_password = data.get('current_password')
    new_password = data.get('new_password')
    
    # Проверяем текущий пароль
    if not current_user.check_password(current_password):
        return jsonify({'error': 'Неверный текущий пароль'}), 400
    
    # Проверяем сложность нового пароля
    if len(new_password) < 6:
        return jsonify({'error': 'Пароль должен содержать минимум 6 символов'}), 400
    
    # Меняем пароль
    current_user.set_password(new_password)
    db.session.commit()
    
    log_audit('Изменен пароль пользователя', 'users', current_user.id, None, {})
    
    return jsonify({'message': 'Пароль успешно изменен'}), 200

@main.route('/api/stats')
@login_required
def get_stats():
    """Получение статистики"""
    if current_user.role != 'admin':
        return jsonify({'error': 'Недостаточно прав'}), 403
    
    # Общая статистика
    total_students = User.query.filter_by(role='student').count()
    total_teachers = User.query.filter_by(role='teacher').count()
    total_diplomas = Diploma.query.count()
    total_news = News.query.count()
    
    # Статистика по уровням дипломов
    levels = ['районный', 'городской', 'региональный', 'федеральный', 'международный']
    level_stats = {}
    
    for level in levels:
        count = Diploma.query.filter_by(level=level).count()
        level_stats[level] = count
    
    return jsonify({
        'total_students': total_students,
        'total_teachers': total_teachers,
        'total_diplomas': total_diplomas,
        'total_news': total_news,
        'level_stats': level_stats
    })

@main.route('/api/audit_log')
@login_required
def get_audit_log():
    """Получение лога действий"""
    if current_user.role != 'admin':
        return jsonify({'error': 'Недостаточно прав'}), 403
    
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(100).all()
    
    result = []
    for log in logs:
        user = User.query.get(log.user_id)
        result.append({
            'id': log.id,
            'timestamp': log.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'user': user.full_name if user else 'Неизвестно',
            'action': log.action,
            'table': log.table_name,
            'record_id': log.record_id
        })
    
    return jsonify(result)

@main.route('/debug/rating')
@login_required
def debug_rating():
    """Отладочная информация по рейтингу"""
    # Простая проверка
    ratings = Rating.query.all()
    users = User.query.filter_by(role='student').all()
    
    return jsonify({
        'total_ratings': len(ratings),
        'total_students': len(users),
        'ratings': [
            {
                'id': r.id,
                'student_id': r.student_id,
                'total_points': r.total_points,
                'position': r.position
            }
            for r in ratings[:10]
        ]
    })

# ========== СИСТЕМНЫЕ МАРШРУТЫ ==========
@main.route('/settings')
@login_required
def settings():
    """Страница настроек"""
    return render_template('settings.html')

@main.route('/api/system/health')
def system_health():
    """Проверка здоровья системы"""
    try:
        # Проверяем подключение к БД
        db.session.execute('SELECT 1')
        db_status = 'OK'
    except:
        db_status = 'ERROR'
    
    # Проверяем доступность папок
    uploads_dir = os.path.join(BASE_DIR, '..', 'uploads')
    uploads_status = 'OK' if os.path.exists(uploads_dir) else 'ERROR'
    
    return jsonify({
        'status': 'OK',
        'timestamp': datetime.utcnow().isoformat(),
        'database': db_status,
        'uploads_folder': uploads_status,
        'version': '1.0.0'
    })

# ========== ОБРАБОТЧИКИ ОШИБОК ==========
@main.app_errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@main.app_errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500