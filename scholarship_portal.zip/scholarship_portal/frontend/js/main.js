// Основной JavaScript файл

// Загрузка топ-5 рейтинга на главной странице
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('top5-table')) {
        loadTop5Rating();
    }
    
    // Инициализация всех форм
    initForms();
    
    // Инициализация модальных окон
    initModals();
});

// Загрузка топ-5 рейтинга
async function loadTop5Rating() {
    try {
        const response = await fetch('/api/rating/top10');
        const data = await response.json();
        
        const tableBody = document.querySelector('#top5-table tbody');
        tableBody.innerHTML = '';
        
        data.slice(0, 5).forEach(item => {
            const row = document.createElement('tr');
            
            let medalIcon = '';
            if (item.position === 1) medalIcon = '<i class="fas fa-medal medal"></i>';
            else if (item.position === 2) medalIcon = '<i class="fas fa-medal" style="color: #C0C0C0;"></i>';
            else if (item.position === 3) medalIcon = '<i class="fas fa-medal" style="color: #CD7F32;"></i>';
            
            row.innerHTML = `
                <td>${medalIcon} ${item.position}</td>
                <td>${item.name}</td>
                <td>${item.class}</td>
                <td><strong>${item.points}</strong></td>
            `;
            
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Ошибка при загрузке рейтинга:', error);
    }
}

// Инициализация форм
function initForms() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Валидация формы
            if (!validateForm(this)) {
                return;
            }
            
            // Отправка формы
            submitForm(this);
        });
    });
}

// Валидация формы
function validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
            
            // Показ сообщения об ошибке
            const errorMsg = document.createElement('div');
            errorMsg.className = 'error-message';
            errorMsg.textContent = 'Это поле обязательно для заполнения';
            errorMsg.style.color = 'red';
            errorMsg.style.fontSize = '0.9rem';
            errorMsg.style.marginTop = '5px';
            
            input.parentNode.appendChild(errorMsg);
            
            // Удаление сообщения об ошибке при вводе
            input.addEventListener('input', function() {
                this.classList.remove('error');
                if (this.parentNode.querySelector('.error-message')) {
                    this.parentNode.removeChild(this.parentNode.querySelector('.error-message'));
                }
            });
        }
    });
    
    return isValid;
}

// Отправка формы
async function submitForm(form) {
    const formData = new FormData(form);
    const action = form.getAttribute('action') || form.action;
    const method = form.getAttribute('method') || 'POST';
    
    try {
        const response = await fetch(action, {
            method: method,
            body: formData
        });
        
        if (response.ok) {
            const result = await response.json();
            showNotification('Успешно!', 'success');
            
            // Перенаправление если указано
            if (result.redirect) {
                setTimeout(() => {
                    window.location.href = result.redirect;
                }, 1000);
            }
        } else {
            showNotification('Ошибка при отправке формы', 'error');
        }
    } catch (error) {
        console.error('Ошибка:', error);
        showNotification('Ошибка сети', 'error');
    }
}

// Показ уведомлений
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Удаление уведомления через 3 секунды
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Инициализация модальных окон
function initModals() {
    // Кнопки открытия модальных окон
    const modalTriggers = document.querySelectorAll('[data-modal-target]');
    
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal-target');
            const modal = document.getElementById(modalId);
            
            if (modal) {
                modal.style.display = 'block';
                
                // Закрытие при клике вне модального окна
                modal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        this.style.display = 'none';
                    }
                });
                
                // Кнопка закрытия
                const closeBtn = modal.querySelector('.close-modal');
                if (closeBtn) {
                    closeBtn.addEventListener('click', function() {
                        modal.style.display = 'none';
                    });
                }
            }
        });
    });
}

// Функция для выбора нескольких учеников
function initStudentSelect() {
    const studentSelect = document.getElementById('studentSelect');
    
    if (studentSelect) {
        // Загрузка списка учеников
        fetch('/api/users/student')
            .then(response => response.json())
            .then(students => {
                students.forEach(student => {
                    const option = document.createElement('option');
                    option.value = student.id;
                    option.textContent = `${student.full_name} (${student.class})`;
                    studentSelect.appendChild(option);
                });
                
                // Инициализация мультиселекта
                $(studentSelect).select2({
                    placeholder: 'Выберите учеников',
                    allowClear: true
                });
            });
    }
}

// Анимации
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .form-control.error {
        border-color: #f44336;
        box-shadow: 0 0 0 3px rgba(244, 67, 54, 0.1);
    }
`;
document.head.appendChild(style);