-- Создание таблиц

-- Таблица пользователей
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL DEFAULT 'student', -- student, teacher, admin, parent
    class VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица грамот/дипломов
CREATE TABLE diplomas (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    level VARCHAR(50) NOT NULL, -- районный, городской, региональный, федеральный, международный
    participation_type VARCHAR(50) DEFAULT 'оффлайн', -- онлайн/оффлайн
    points INTEGER NOT NULL,
    file_path VARCHAR(500),
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    start_date DATE,
    end_date DATE
);

-- Таблица участия учеников в мероприятиях
CREATE TABLE participations (
    id SERIAL PRIMARY KEY,
    diploma_id INTEGER REFERENCES diplomas(id) ON DELETE CASCADE,
    student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    mentor_id INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица рейтинга (вычисляемая)
CREATE TABLE ratings (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id) UNIQUE,
    total_points INTEGER DEFAULT 0,
    academic_points INTEGER DEFAULT 0,
    extracurricular_points INTEGER DEFAULT 0,
    position INTEGER,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица новостей
CREATE TABLE news (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50),
    author_id INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_published BOOLEAN DEFAULT TRUE
);

-- Таблица журнала действий
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(200) NOT NULL,
    table_name VARCHAR(50),
    record_id INTEGER,
    old_data JSONB,
    new_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы для ускорения поиска
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_diplomas_level ON diplomas(level);
CREATE INDEX idx_participations_student ON participations(student_id);
CREATE INDEX idx_ratings_points ON ratings(total_points DESC);
CREATE INDEX idx_news_category ON news(category);

-- Триггер для автоматического обновления рейтинга
CREATE OR REPLACE FUNCTION update_rating()
RETURNS TRIGGER AS $$
BEGIN
    -- Пересчет баллов для ученика
    UPDATE ratings 
    SET total_points = (
        SELECT COALESCE(SUM(d.points), 0)
        FROM participations p
        JOIN diplomas d ON p.diploma_id = d.id
        WHERE p.student_id = NEW.student_id
    )
    WHERE student_id = NEW.student_id;
    
    -- Обновление позиций в рейтинге
    WITH ranked AS (
        SELECT student_id, total_points,
               ROW_NUMBER() OVER (ORDER BY total_points DESC) as new_position
        FROM ratings
    )
    UPDATE ratings r
    SET position = ranked.new_position
    FROM ranked
    WHERE r.student_id = ranked.student_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_rating
AFTER INSERT OR UPDATE OR DELETE ON participations
FOR EACH ROW
EXECUTE FUNCTION update_rating();